#include <stdio.h>
#include <string.h>

char	*ft_strlowcase(char *str);

int main (){
    char a[] = "sdfALJB";
    printf("%s ", a);
    printf("%s\n", ft_strlowcase(a));
    char b[] = " asd asd as as ";
    printf("%s %s\n", b, ft_strlowcase(b));
    char c[] = "54t4tu340295u93";
    printf("%s %s\n", c, ft_strlowcase(c));
    char d[] = "-*/-*/-*/-*/";
    printf("%s %s\n", d, ft_strlowcase(d));
    char e[] = "";
    printf("%s %s\n", e, ft_strlowcase(e));
    char f[] = "vVvVvVvVvVvV";
    printf("%s %s\n", f, ft_strlowcase(f));
    char g[] = "641318943218465";
    printf("%s %s\n", g, ft_strlowcase(g));
    char h[] = "gbqejgbqjrgbqj";
    printf("%s %s\n", h, ft_strlowcase(h));
    char i[] = "KHBKJBKJBJ";
    printf("%s %s\n", i, ft_strlowcase(i));
    char j[] = "\0\\\tsdf\0";
    printf("%s %s\n", j, ft_strlowcase(j));
}