#include <stdio.h>

int ft_str_is_alpha(char *str);

int main (){
    char a[] = "sdfALJB";
    printf("%s %d\n", a, ft_str_is_alpha(a));
    char b[] = " asd asd as as ";
    printf("%s %d\n", b, ft_str_is_alpha(b));
    char c[] = "54t4tu340295u93";
    printf("%s %d\n", c, ft_str_is_alpha(c));
    char d[] = "-*/-*/-*/-*/";
    printf("%s %d\n", d, ft_str_is_alpha(d));
    char e[] = "";
    printf("%s %d\n", e, ft_str_is_alpha(e));
    char f[] = "vVvVvVvVvVvV";
    printf("%s %d\n", f, ft_str_is_alpha(f));
}