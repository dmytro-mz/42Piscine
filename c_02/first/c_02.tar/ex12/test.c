#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>

#include <unistd.h>
#include <stdint.h>

void	print_mem_address(void *addr)
{
	uintptr_t	addr_int;
	char		mem_char[16];
	int			i;

	addr_int = (uintptr_t)addr;
	i = 15;
	while (i >= 0)
	{
		mem_char[i] = "0123456789abcdef"[addr_int >> (4 * (15 - i)) & 0xF];
		i--;
	}
	write(1, mem_char, 16);
	write(1, ": ", 2);
}

void	print_hex_chars(void *addr)
{
	int	i;

	i = 0;
	while (i < 16 && ((char *)addr)[i] != '\0')
	{
		if ((i) % 2 == 0 && i > 0)
			write(1, " ", 1);
		write(1, &"0123456789abcdef"[((char *)addr)[i] >> 4], 1);
		write(1, &"0123456789abcdef"[((char *)addr)[i] & 0xF], 1);
		i++;
	}
	if (i < 16)
	{
		write(1, "00", 2);
		i++;
		while (i < 16)
		{
			if ((i) % 2 == 0 && i > 0)
				write(1, " ", 1);
			write(1, "  ", 2);
			i++;
		}
	}
	write(1, " ", 1);
}

void	print_text(void *addr)
{
	int	i;

	i = 0;
	while (i < 16 && ((char *)addr)[i] != '\0')
	{
		if (((char *)addr)[i] >= 32 && ((char *)addr)[i] <= 126)
			write(1, &((char *)addr)[i], 1);
		else
			write(1, ".", 1);
		i++;
	}
	if (i < 16)
		write(1, ".", 1);
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	unsigned int	i;

	i = 0;
	while (i < size)
	{
		if (i > 0)
			write(1, "\n", 1);
		print_mem_address(addr + i);
		print_hex_chars(addr + i);
		print_text(addr + i);
		i += 16;
	}
	return (addr);
}

int main() {
    // Hex string
    const char hexString[] = "426f6e6a6f7572206c657320616d696e63686573090a0963072065737420666f7509746f7574096365207175206f6e20706575742066616972652061766563090a097072696e745f6d656d6f72790a0a0a096c6f6c2e6c6f6c0a2000";

    // Function to convert hex string to ASCII string
    int hexToAscii(const char *hexString, char *asciiString) {
        int len = strlen(hexString);
        if (len % 2 != 0) {
            // Odd number of characters in hex string
            return -1;
        }

        for (int i = 0, j = 0; i < len; i += 2, j++) {
            sscanf(hexString + i, "%2hhx", &asciiString[j]);
        }

        // Null-terminate the ASCII string
        asciiString[len / 2] = '\0';

        return 0;
    }

    // Calculate the length of the ASCII string
    int asciiLength = strlen(hexString) / 2;

    // Allocate memory for the ASCII string
    char asciiString[asciiLength + 1];

    // Convert hex to ASCII
    if (hexToAscii(hexString, asciiString) != 0)
        printf("Error: Unable to convert hex to ASCII.\n");
    
    // Function to print string as hexadecimal
    //void printStringAsHex(char *str) {
    //    for (int i = 0; str[i] != '\0'; i++) {
    //        printf("%02x", (unsigned char)str[i]);
    //    }
    //    printf("\n");
    //}

    // Print the ASCII string as hexadecimal
    // printStringAsHex(asciiString);
    
    ///
    /// start
    ///
    
    ft_print_memory(asciiString, asciiLength);

    return 0;
}
