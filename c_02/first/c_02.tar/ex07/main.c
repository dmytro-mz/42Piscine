#include <stdio.h>
#include <string.h>

char	*ft_strupcase(char *str);

int main (){
    char a[] = "sdfALJB";
    printf("%s ", a);
    printf("%s\n", ft_strupcase(a));
    char b[] = " asd asd as as ";
    printf("%s %s\n", b, ft_strupcase(b));
    char c[] = "54t4tu340295u93";
    printf("%s %s\n", c, ft_strupcase(c));
    char d[] = "-*/-*/-*/-*/";
    printf("%s %s\n", d, ft_strupcase(d));
    char e[] = "";
    printf("%s %s\n", e, ft_strupcase(e));
    char f[] = "vVvVvVvVvVvV";
    printf("%s %s\n", f, ft_strupcase(f));
    char g[] = "641318943218465";
    printf("%s %s\n", g, ft_strupcase(g));
    char h[] = "gbqejgbqjrgbqj";
    printf("%s %s\n", h, ft_strupcase(h));
    char i[] = "KHBKJBKJBJ";
    printf("%s %s\n", i, ft_strupcase(i));
    char j[] = "\0\\\tsdf\0";
    printf("%s %s\n", j, ft_strupcase(j));
}