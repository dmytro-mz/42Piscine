#include <stdio.h>

int ft_str_is_printable(char *str);

int main (){
    char a[] = "sdfALJB";
    printf("%s %d\n", a, ft_str_is_printable(a));
    char b[] = " asd asd as as ";
    printf("%s %d\n", b, ft_str_is_printable(b));
    char c[] = "54t4tu340295u93";
    printf("%s %d\n", c, ft_str_is_printable(c));
    char d[] = "-*/-*/-*/-*/";
    printf("%s %d\n", d, ft_str_is_printable(d));
    char e[] = "";
    printf("%s %d\n", e, ft_str_is_printable(e));
    char f[] = "vVvVvVvVvVvV";
    printf("%s %d\n", f, ft_str_is_printable(f));
    char g[] = "641318943218465";
    printf("%s %d\n", g, ft_str_is_printable(g));
    char h[] = "gbqejgbqjrgbqj";
    printf("%s %d\n", h, ft_str_is_printable(h));
    char i[] = "KHBKJBKJBJ";
    printf("%s %d\n", i, ft_str_is_printable(i));
    char j[] = "\0\\\tsdf\0";
    printf("%s %d\n", j, ft_str_is_printable(j));
}