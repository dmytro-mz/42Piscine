#include <stdio.h>
#include <string.h>

char *ft_strcpy(char *dest, char *src);

int main()
{
	char str1[50] = "first string";
	char *str2  = "second string";

	printf("%s\n%s\n\n", str1, str2);
	ft_strcpy(str1, str2);
	printf("%s\n%s\n\n", str1, str2);
}
