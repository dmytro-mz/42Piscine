#include <stdio.h>

int ft_str_is_numeric(char *str);

int main (){
    char a[] = "sdfALJB";
    printf("%s %d\n", a, ft_str_is_numeric(a));
    char b[] = " asd asd as as ";
    printf("%s %d\n", b, ft_str_is_numeric(b));
    char c[] = "54t4tu340295u93";
    printf("%s %d\n", c, ft_str_is_numeric(c));
    char d[] = "-*/-*/-*/-*/";
    printf("%s %d\n", d, ft_str_is_numeric(d));
    char e[] = "";
    printf("%s %d\n", e, ft_str_is_numeric(e));
    char f[] = "vVvVvVvVvVvV";
    printf("%s %d\n", f, ft_str_is_numeric(f));
    char g[] = "641318943218465";
    printf("%s %d\n", g, ft_str_is_numeric(g));
}