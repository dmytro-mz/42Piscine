#include <stdio.h>
#include <unistd.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n);

int main()
{
	char str1_1[] = "abcdefg";
        char str2_1[] = "abcdefg";
	char *str3_1  = "0123456";

	printf("%s\n%s\n%d\n\n", str1_1, str3_1, 2);
        printf("%d\n\n", strcmp(ft_strncpy(str1_1, str3_1, 2), strncpy(str2_1, str3_1, 2)));

	char str1_2[] = "abcdefg";
        char str2_2[] = "abcdefg";
        char *str3_2  = "0123";

        printf("%s\n%s\n%d\n\n", str1_2, str3_2, 5);
        printf("%d\n\n", strcmp(ft_strncpy(str1_2, str3_2, 2), strncpy(str2_2, str3_2, 2)));

	char str1_3[] = "abcdefg";
        char str2_3[] = "abcdefg";
        char *str3_3  = "012";

        printf("%s\n%s\n%d\n\n", str1_3, str3_3, 8);
        printf("%d\n\n", strcmp(ft_strncpy(str1_3, str3_3, 2), strncpy(str2_3, str3_3, 2)));
}
