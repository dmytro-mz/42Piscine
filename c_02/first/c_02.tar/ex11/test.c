#include <stdio.h>
#include <unistd.h>

void ft_putstr_non_printable(char *str)
{
    int i;
    char *hex_chars;
    
    hex_chars = "0123456789abcdef";
    i = 0;
    while (str[i] != '\0')
    {
        if (str[i] >= 32 && str[i] <= 126)   // FIX 06!!!
            write(1, &str[i], 1);
        else
        {
            write(1, "\\", 1);
            write(1, &hex_chars[str[i] >> 4], 1);
            write(1, &hex_chars[str[i] & 0x0F], 1);
        }
        i++;
    }
}

int main()
{
    char *a = "Coucou\ntu vas bien ?";
    printf("%s\n", a);
    ft_putstr_non_printable(a);
    return 0;
}
