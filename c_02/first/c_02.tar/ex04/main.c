#include <stdio.h>

int ft_str_is_lowercase(char *str);

int main (){
    char a[] = "sdfALJB";
    printf("%s %d\n", a, ft_str_is_lowercase(a));
    char b[] = " asd asd as as ";
    printf("%s %d\n", b, ft_str_is_lowercase(b));
    char c[] = "54t4tu340295u93";
    printf("%s %d\n", c, ft_str_is_lowercase(c));
    char d[] = "-*/-*/-*/-*/";
    printf("%s %d\n", d, ft_str_is_lowercase(d));
    char e[] = "";
    printf("%s %d\n", e, ft_str_is_lowercase(e));
    char f[] = "vVvVvVvVvVvV";
    printf("%s %d\n", f, ft_str_is_lowercase(f));
    char g[] = "641318943218465";
    printf("%s %d\n", g, ft_str_is_lowercase(g));
    char h[] = "gbqejgbqjrgbqj";
    printf("%s %d\n", h, ft_str_is_lowercase(h));
}