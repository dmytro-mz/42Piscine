#include <stdio.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size);

int main()
{
    char a[50] = "qwertyuiop";
    char *b = "123";
    printf("%s, %d\n", a, (int)ft_strlcpy(a, b, 3));
    for (int i = 0; i < 10; i++)
        printf("%d ", a[i]);
    printf("\n");

    printf("%s, %d\n", a, (int)ft_strlcpy(a, b, 4));
    for (int i = 0; i < 10; i++)
        printf("%d ", a[i]);
    printf("\n");

    printf("%s, %d\n", a, (int)ft_strlcpy(a, b, 7));
    for (int i = 0; i < 10; i++)
        printf("%d ", a[i]);
    printf("\n");
}
