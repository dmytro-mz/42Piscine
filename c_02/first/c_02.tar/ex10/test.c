#include <stdio.h>
#include <string.h>
#include <stddef.h>

size_t strlcpy(char *dest, const char *src, size_t size) {
    size_t i;
    
    for (i = 0; i < size - 1 && src[i] != '\0'; ++i) {
        dest[i] = src[i];
    }
    
    dest[i] = '\0';

    // Calculate the length of the source string
    while (src[i] != '\0') {
        ++i;
    }

    return i;
}

int main()
{
    char a[50] = "qwertyuiop";
    char *b = "123";
    printf("%s, %d\n", a, (int)strlcpy(a, b, 3));
    for (int i = 0; i < 10; i++)
        printf("%d ", a[i]);
    printf("\n");

    printf("%s, %d\n", a, (int)strlcpy(a, b, 4));
    for (int i = 0; i < 10; i++)
        printf("%d ", a[i]);
    printf("\n");

    printf("%s, %d\n", a, (int)strlcpy(a, b, 7));
    for (int i = 0; i < 10; i++)
        printf("%d ", a[i]);
    printf("\n");
}